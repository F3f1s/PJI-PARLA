# Classe User definida.
class User:
    def __init__(self, id, nome, idade, genero, email, senha):
        self.id = id
        self.nome = nome
        self.idade = idade
        self.genero = genero
        self.email = email
        self.senha = senha
