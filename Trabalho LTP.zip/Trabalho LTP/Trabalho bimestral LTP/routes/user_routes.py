from flask import Blueprint, request, jsonify
from services.user_service import add_user, get_user

user_bp = Blueprint('user_bp', __name__)

@user_bp.route('/users', methods=['POST'])
def create():
    # Extract user data from request
    user_data = request.get_json()
    
    # Call add_user from user_service
    response = add_user(user_data)
    
    # Return response as JSON
    return jsonify(response), 201

@user_bp.route('/users/<int:user_id>', methods=['GET'])
def get(user_id):
    # Call get_user from user_service
    response = get_user(user_id)
    
    # Return response as JSON
    return jsonify(response), 200