from flask import Blueprint, request, jsonify
from services.personagem_service import (
    add_personagem, get_personagem, get_personagens,
    edit_personagem, remove_personagem
)

personagem_bp = Blueprint('personagem_bp', __name__)

@personagem_bp.route('/personagens', methods=['POST'])
def criar_personagem():
    data = request.get_json()
    id = add_personagem(
        data.get('usuario_id'),
        data.get('sapato'),
        data.get('acessorios'),
        data.get('roupa'),
        data.get('cabelo'),
        data.get('corpo')
    )
    return jsonify({'id': id}), 201

@personagem_bp.route('/personagens', methods=['GET'])
def listar_personagens():
    personagens = get_personagens()
    return jsonify(personagens), 200

@personagem_bp.route('/personagens/<int:personagem_id>', methods=['GET'])
def buscar_personagem(personagem_id):
    personagem = get_personagem(personagem_id)
    if personagem:
        return jsonify(personagem), 200
    return jsonify({'erro': 'Personagem não encontrado'}), 404

@personagem_bp.route('/personagens/<int:personagem_id>', methods=['PUT'])
def atualizar_personagem(personagem_id):
    data = request.get_json()
    edit_personagem(
        personagem_id,
        data.get('sapato'),
        data.get('acessorios'),
        data.get('roupa'),
        data.get('cabelo'),
        data.get('corpo')
    )
    return jsonify({'msg': 'Personagem atualizado'}), 200

@personagem_bp.route('/personagens/<int:personagem_id>', methods=['DELETE'])
def deletar_personagem(personagem_id):
    remove_personagem(personagem_id)
    return jsonify({'msg': 'Personagem deletado'}), 200
