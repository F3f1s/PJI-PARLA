from flask import Blueprint, request, jsonify
from dao.post_dao import (
    create_post, get_post_by_id, get_posts_by_user,
    get_all_posts, update_post, delete_post
)

# Define o blueprint para as rotas de posts
# Agrupa todas as rotas relacionadas a posts sob o prefixo 'post_bp'
post_bp = Blueprint('post_bp', __name__)

# -------------------------------------------
# RECADO IMPORTANTE:
# Este arquivo deve conter as rotas relacionadas a posts.
# Utilize o blueprint 'post_bp' para agrupar todas as rotas dessa entidade.
# Siga a estrutura definida para facilitar manutenção, testes e apresentação!
# -------------------------------------------

# Blueprint 'post_bp' definido para rotas de posts.
# Comentário explicativo sobre uso do blueprint.
# Ainda não há rotas implementadas.

@post_bp.route('/posts', methods=['POST'])
def criar_post():
    data = request.get_json()
    post_id = create_post(
        data.get('user_id'),
        data.get('title'),
        data.get('content')
    )
    return jsonify({'id': post_id}), 201

@post_bp.route('/posts', methods=['GET'])
def listar_posts():
    posts = get_all_posts()
    return jsonify(posts), 200

@post_bp.route('/posts/<int:post_id>', methods=['GET'])
def buscar_post(post_id):
    post = get_post_by_id(post_id)
    if post:
        return jsonify(post), 200
    return jsonify({'erro': 'Post não encontrado'}), 404

@post_bp.route('/posts/user/<int:user_id>', methods=['GET'])
def listar_posts_usuario(user_id):
    posts = get_posts_by_user(user_id)
    return jsonify(posts), 200

@post_bp.route('/posts/<int:post_id>', methods=['PUT'])
def atualizar_post(post_id):
    data = request.get_json()
    update_post(
        post_id,
        data.get('title'),
        data.get('content')
    )
    return jsonify({'msg': 'Post atualizado'}), 200

@post_bp.route('/posts/<int:post_id>', methods=['DELETE'])
def deletar_post(post_id):
    delete_post(post_id)
    return jsonify({'msg': 'Post deletado'}), 200